import io
import json
import time

import streamlit as st
from PIL import Image
from streamlit_cropper import st_cropper

from service import fetch_models, extract_receipt

st.set_page_config(layout="wide", page_title="Donut KIE — Receipt Extraction")

# ── CSS ──
st.markdown(
    """
<style>
    .block-container {
        padding-top: 1.5rem;
        padding-bottom: 2rem;
        max-width: 1300px;
    }
    .section-label {
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        opacity: 0.65;
        margin-bottom: 0.5rem;
    }
    .app-title {
        font-size: 1.6rem;
        font-weight: 700;
    }
    .badge {
        display: inline-block;
        font-size: 0.68rem;
        font-weight: 600;
        padding: 0.15rem 0.5rem;
        border-radius: 999px;
        border: 1px solid rgba(255,255,255,0.2);
        opacity: 0.85;
        margin-right: 0.3rem;
    }
    .badge-rec { background: rgba(75,192,192,0.15); color: #4bc0c0; }
    .badge-warn { background: rgba(255,159,64,0.15); color: #ff9f40; }
    .status-row {
        display: flex;
        align-items: center;
        gap: 1.5rem;
        font-size: 0.82rem;
        opacity: 0.75;
        padding: 0.4rem 0;
    }
    .metric-label {
        font-size: 0.65rem;
        text-transform: uppercase;
        opacity: 0.5;
    }
    .metric-value {
        font-size: 1.1rem;
        font-weight: 600;
    }
    .drop-zone {
        border: 2px dashed rgba(255,255,255,0.2);
        border-radius: 12px;
        padding: 3rem 2rem;
        text-align: center;
        transition: border-color 0.2s;
    }
    .drop-zone:hover {
        border-color: rgba(255,255,255,0.4);
    }
</style>
""",
    unsafe_allow_html=True,
)

# ── Session state ──
DEFAULTS = {
    "step": 1,
    "uploaded_bytes": None,
    "uploaded_name": None,
    "uploaded_type": None,
    "cropped_bytes": None,
    "result_data": None,
    "model_data": None,
    "compare_data": None,
    "rotate_angle": 0,
}

for key, default in DEFAULTS.items():
    if key not in st.session_state:
        st.session_state[key] = default


def reset_all():
    for key, default in DEFAULTS.items():
        st.session_state[key] = default
    st.rerun()


# ── Helpers ──

def _load_image():
    if st.session_state.cropped_bytes is not None:
        return Image.open(io.BytesIO(st.session_state.cropped_bytes))
    if st.session_state.uploaded_bytes is not None:
        return Image.open(io.BytesIO(st.session_state.uploaded_bytes))
    return None


def _fmt(val):
    if val is None:
        return "Not detected"
    return str(val)


# ── Stepper ──

def render_stepper():
    steps = ["Upload", "Crop", "Results"]
    cols = st.columns(len(steps))
    for i, s in enumerate(steps):
        n = i + 1
        done = st.session_state.step > n
        active = st.session_state.step == n
        with cols[i]:
            if done:
                st.markdown(f"<span style='opacity:0.5;text-decoration:line-through;'>{n}. {s}</span>", unsafe_allow_html=True)
            elif active:
                st.markdown(f"<b>{n}. {s}</b>", unsafe_allow_html=True)
            else:
                st.markdown(f"<span style='opacity:0.35;'>{n}. {s}</span>", unsafe_allow_html=True)


# ── Step 1: Upload ──

def render_upload():
    c1, c2, c3 = st.columns([1, 2, 1])
    with c2:
        with st.container(border=True):
            st.markdown("### Drop a receipt image here")
            st.caption("JPG, PNG, WEBP  ·  Maximum 10 MB")

            uploaded = st.file_uploader(
                "Upload receipt",
                type=["jpg", "jpeg", "png", "webp"],
                label_visibility="collapsed",
                key="upload_widget",
            )

            if uploaded is not None:
                if uploaded.size > 10 * 1024 * 1024:
                    st.error("File too large. Maximum 10 MB.")
                    return

                st.session_state.uploaded_bytes = uploaded.getvalue()
                st.session_state.uploaded_name = uploaded.name
                st.session_state.uploaded_type = uploaded.type
                st.session_state.cropped_bytes = None
                st.session_state.result_data = None
                st.session_state.rotate_angle = 0
                st.session_state.step = 2
                st.rerun()


# ── Step 2: Crop ──

def render_crop():
    img = _load_image()
    if img is None:
        st.error("No image found. Please go back and upload.")
        if st.button("← Back to upload"):
            st.session_state.step = 1
            st.rerun()
        return

    # rotate
    if st.session_state.rotate_angle != 0:
        img = img.rotate(st.session_state.rotate_angle, expand=True)

    col_left, col_right = st.columns([3, 1])
    with col_left:
        cropped = st_cropper(img, realtime_update=True, box_color="#FF4B4B", aspect_ratio=None)
    with col_right:
        st.markdown("**Crop settings**")
        st.caption(f"Original: {img.size[0]}×{img.size[1]}")
        st.caption(f"Cropped: {cropped.size[0]}×{cropped.size[1]}")

        c_btns = st.columns(2)
        with c_btns[0]:
            if st.button("↺ Rotate left", use_container_width=True, key="rot_l"):
                st.session_state.rotate_angle = (st.session_state.rotate_angle + 90) % 360
                st.rerun()
        with c_btns[1]:
            if st.button("↻ Rotate right", use_container_width=True, key="rot_r"):
                st.session_state.rotate_angle = (st.session_state.rotate_angle - 90) % 360
                st.rerun()

        if st.button("Reset crop", use_container_width=True, key="reset_crop"):
            st.session_state.rotate_angle = 0
            st.rerun()

        st.divider()

        if st.button("Use this image", type="primary", use_container_width=True):
            buf = io.BytesIO()
            cropped.save(buf, format="PNG")
            st.session_state.cropped_bytes = buf.getvalue()
            st.session_state.rotate_angle = 0
            st.session_state.step = 3
            st.rerun()

        if st.button("Use original image", use_container_width=True):
            st.session_state.cropped_bytes = st.session_state.uploaded_bytes
            st.session_state.rotate_angle = 0
            st.session_state.step = 3
            st.rerun()

        if st.button("← Back to upload", use_container_width=True):
            st.session_state.step = 1
            st.rerun()


# ── Step 3: Results ──

def render_results():
    models = fetch_models()
    if not models:
        st.error("Backend is unavailable.")
        return

    model_map = {m["id"]: m for m in models}
    model_opts = list(model_map.keys())
    default_idx = 0
    for i, m in enumerate(models):
        if m.get("recommended"):
            default_idx = i
            break

    with st.container():
        hc1, hc2, hc3 = st.columns([2, 3, 1])
        with hc1:
            st.markdown(f"**Donut KIE**  \n<small>{st.session_state.uploaded_name}</small>", unsafe_allow_html=True)
        with hc2:
            selected_id = st.selectbox(
                "Model",
                model_opts,
                index=default_idx,
                format_func=lambda rid: model_map[rid]["name"],
                label_visibility="collapsed",
            )
        with hc3:
            c_btn1, c_btn2 = st.columns(2)
            with c_btn1:
                run = st.button("▶ Extract", type="primary", use_container_width=True)
            with c_btn2:
                if st.button("🔄 New", use_container_width=True):
                    reset_all()

    selected_model = model_map[selected_id]
    st.divider()

    file_bytes = st.session_state.cropped_bytes or st.session_state.uploaded_bytes

    # check cached result
    cached = st.session_state.result_data
    if cached and cached.get("model_id") == selected_id:
        result_json = cached
    elif run:
        with st.spinner("Running inference..."):
            start = time.time()
            try:
                resp = extract_receipt(
                    selected_id,
                    file_bytes,
                    st.session_state.uploaded_name,
                    st.session_state.uploaded_type,
                )
                latency = time.time() - start
                if resp.status_code == 200:
                    body = resp.json()
                    if body.get("success"):
                        result_json = {
                            "model_id": selected_id,
                            "data": body.get("data", {}),
                            "latency": latency,
                        }
                        st.session_state.result_data = result_json
                    else:
                        st.error(body.get("msg", "Extraction failed"))
                        result_json = None
                else:
                    st.error(f"Backend error: {resp.status_code}")
                    result_json = None
            except Exception as e:
                st.error(f"Connection error: {e}")
                result_json = None
    else:
        result_json = None

    if result_json is None:
        st.info('Upload an image, adjust crop, then click "Extract".')
        return

    # latency row above image + tabs
    pred = (result_json["data"].get("selected") or {}).get("prediction", {})
    st.markdown(
        f'<div class="status-row">'
        f'✅ Extraction complete  ·  '
        f'{result_json["latency"]:.2f}s  ·  '
        f'{selected_model["name"]}'
        f'</div>',
        unsafe_allow_html=True,
    )

    col_img, col_result = st.columns([1, 2])
    with col_img:
        img = _load_image()
        if img:
            st.image(img, use_container_width=True)

    with col_result:
        tabs = st.tabs(["Items", "Raw JSON"])
        with tabs[0]:
            _render_items(pred)
        with tabs[1]:
            _render_json(pred)


# ── Render helpers ──


def _render_items(pred):
    menu = pred.get("menu", []) if isinstance(pred, dict) else []
    if not menu or not isinstance(menu, list):
        st.info("No items detected.")
        return

    rows = []
    for item in menu:
        if isinstance(item, dict):
            nm = item.get("nm") or item.get("name") or "N/A"
            cnt = item.get("cnt") or item.get("count") or "1"
            unit = item.get("unitprice") or item.get("price") or "\u2014"
            total_price = item.get("price") or "\u2014"
            rows.append([nm, cnt, unit, total_price])

    if not rows:
        st.info("No items detected.")
        return

    st.table(
        {"Item": [r[0] for r in rows], "Qty": [r[1] for r in rows], "Unit Price": [r[2] for r in rows], "Total": [r[3] for r in rows]}
    )


def _render_json(pred):
    raw = json.dumps(pred, indent=2, ensure_ascii=False) if isinstance(pred, dict) else str(pred)
    st.code(raw, language="json")

    c1, c2 = st.columns(2)
    with c1:
        st.download_button("Download JSON", raw, file_name="extraction_result.json", mime="application/json", use_container_width=True)


# ── Main ──

render_stepper()
st.divider()

if st.session_state.step == 1:
    render_upload()
elif st.session_state.step == 2:
    render_crop()
elif st.session_state.step == 3:
    render_results()
